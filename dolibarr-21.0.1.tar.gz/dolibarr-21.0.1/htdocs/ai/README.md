# AI FOR [DOLIBARR ERP CRM](https://www.dolibarr.org)

## Features

Provides AI (Artificial Intelligence) features in different part of the application. Need external AI API. 

## Licenses

### Main code

GPLv3 or (at your option) any later version. See file COPYING for more information.

### Documentation

All texts and readmes are licensed under GFDL.
