<?php
/* Copyright (C) 2024		MDW							<mdeweerd@users.noreply.github.com>
 */
return include __DIR__ . "/../dev/tools/phan/config.php";
